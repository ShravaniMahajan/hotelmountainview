document.addEventListener("DOMContentLoaded", function () {
    let isNight = false;
    let sun = document.getElementById("sun");


    // === Day-Night Transition ===
    function toggleDayNight() {
        isNight = !isNight;
        document.body.classList.toggle("night-mode");

    
    }

    // Prevent rapid toggling causing lag
    setTimeout(() => {
        setInterval(toggleDayNight, 15000);
    }, 1000);

    // === Starry Night Effect (Optimized) ===
    function createStars() {
        let starContainer = document.createElement("div");
        starContainer.id = "starContainer";
        document.body.appendChild(starContainer);

        for (let i = 0; i < 50; i++) { // Reduced to 50 for better performance
            let star = document.createElement("div");
            star.classList.add("stars");
            star.style.top = Math.random() * window.innerHeight + "px";
            star.style.left = Math.random() * window.innerWidth + "px";
            starContainer.appendChild(star);
        }
    }

    createStars();
});



document.addEventListener("DOMContentLoaded", function () {
    let isNight = false;

    // === Toggle Day-Night Mode Every 10 Seconds ===
    function toggleDayNight() {
        isNight = !isNight;
        document.body.classList.toggle("night-mode");
    }

    // Switch between Day and Night every 10 seconds
    setInterval(toggleDayNight, 10000);

    

    createStars();
});




